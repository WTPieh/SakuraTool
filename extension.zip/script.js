console.log("This script is running on a page with /chat/ in the URL");
